# PORTFOLIO
This Portfolio is a small project using HTML / CSS and Bootstrap. I will be using this to show my projects!
[Live Replit deployment](https://portfolio.subhamrakshit97.repl.co/)
## Screenshot:
![Screenshot 2022-11-08 at 8 32 10 AM](https://user-images.githubusercontent.com/111345784/200465114-6ca8b332-b67e-4a10-9fee-4e3d6dcc5c34.png)


## Technologies Used
* HTML
* CSS
## Installation
No need to install any software, just open up index.html
## How to use ?
Use this template to build your own portfolio
