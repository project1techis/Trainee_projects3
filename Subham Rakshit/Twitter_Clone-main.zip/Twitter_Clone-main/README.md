# Twitter-clone
A sample web page of Twitter Clone Let’s make simple Twitter. Users can post tweets and see everyone’s them. To make the project simple, we do not have a sign/login function. So there are not user accounts and follow function. You can challenge after you finish the course.
# Screenshot
<img width="1151" alt="Screenshot 2022-10-13 at 6 51 17 AM" src="https://user-images.githubusercontent.com/111345784/195526566-65ccc84a-7c01-4652-9d12-ffa542a97730.png">

# Technologies Used
* HTML
* CSS
* Bootstrap
* Javascript/JQuery
* Django
* Cloudinary(To host uploaded images on CDN)
# User Story
* User can post tweets.
* Users canedit tweets.
* Users can delete tweets.
* Users can send a like to a tweet

