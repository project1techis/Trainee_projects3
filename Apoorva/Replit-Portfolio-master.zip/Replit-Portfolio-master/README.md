# Myportfolio
This is my portfolio project using HTML/CSS and Bootstrap. I will be using this to show case my project!
[live Replit Deployment](https://Replit-Portfolio.apoorvasmr.repl.co)
<img width="1396" alt="Screen Shot 1400-12-12 at 13 08 46" src="https://user-images.githubusercontent.com/99715304/156519177-6c745321-fd34-4eda-b757-8660e129d52a.png">

## Technologies Used
*HTML
*CSS

## Istallation
No need to install any software, just open up index.html

## How to use?
Use this template to build your own portfolio
