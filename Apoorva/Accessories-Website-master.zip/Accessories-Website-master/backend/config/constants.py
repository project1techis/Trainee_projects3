import os
import pytz

##############################
# Items
##############################
STATUS = (
    ('active', 'Active'),
    ('inactive','Inactive'),
)
STATUS_DICT = dict(STATUS)

##############################
# Order
##############################
COUNTRIES = (
    ('united_state', 'United State'),
    ('india', 'India'),
    ('japan', 'Japan'),
    ('canada', 'Canada'),
    ('united_kingdom', 'United Kingdom'),
)