# Twitter-Clone
A sample web page of twitter. Twitter clone Let's make simple twitter. Users can post tweets and see everyone's Post To make the project simple, we do not have a login So there are not user accounts and follow functions.
Check Out [LIVE DEMO HERE...!!!](https://Replit-Twitter-Clone.apoorvasmr.repl.co)

# Screenshot:
 <img width="643" alt="Screenshot 2022-03-18 at 11 31 48 AM" src="https://user-images.githubusercontent.com/99715304/158948562-70ca9884-d9f9-494f-b1fc-28078f8c107f.png">

# Tech Used:
* HTML
* CSS 
* JavaScript 
* Django
* Cloudinary(The host to upload images on CDN)

# User Story:
* Users can post tweets 
* Users can edit tweets
* Users can delete tweets 
* Users can send a like to a tweet
