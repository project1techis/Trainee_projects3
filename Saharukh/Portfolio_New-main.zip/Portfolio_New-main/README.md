# New_Portfolio
This portfolio is a small project using the HTML/CSS and Bootstrap. I will be using the this to showcase my projects and skills 

[LIVE REPLIT DEPLOYMENT](https://portfolionew.saharukhshaikh.repl.co/)


# Technologies Used:
* HTML 
* CSS

# Installation
 No need to install any software, just open up index.html
 
# How to use?
Use this template to build your own portfolio

# Screenshot:!

<img width="1425" alt="Screenshot 2022-11-08 at 08 54 18" src="https://user-images.githubusercontent.com/102286564/200468149-e185c755-df5f-4543-9786-029d240b0ed8.png">
