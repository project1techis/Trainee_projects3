# portfolio
This portfolio is a project using HTML, CSS and bootstrap. This Portfolio is to show case my projects.

[live Heroku Deployment](https://portfolio-abhinand.herokuapp.com/)

[live Replit Deployment](https://portfolio.abhinandv1.repl.co)

![Screenshot 2022-10-18 at 7 35 43 AM](https://user-images.githubusercontent.com/107241846/196318478-0cda122d-3857-4310-a215-08abc3aeb0f3.png)



## Technologies used.

* HTML5
* CSS3

## Installation

No need to install any software, just open up index.html

## How to use ?

Use the template to build your own portfolio
