//////hello////////

$(function() {
    $('.js-list-icon').click(function(){

        $(this).next().toggle();
    })
})