# Portfolio
This portfolio is a small project using the HTML/CSS and Bootstrap. I will be using the this to showcase my projects and skills [LIVE HEROKU DEPLOYMENT](https://portfolio-shubhams.herokuapp.com/)

# Screenshot:
 <img width="1373" alt="Screenshot 2022-03-15 at 2 33 29 PM" src="https://user-images.githubusercontent.com/100840176/158343241-3ba369b4-1eb1-46df-addd-c26ad22bc953.png">

# Technologies Used:
* HTML 
* CSS

# Installation
 No need to install any software, just open up index.html
 
# How to use?
Use this template to build your own portfolio
 
