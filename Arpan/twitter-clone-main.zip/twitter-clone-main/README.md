# Twitter-clone
A sample web page of Twitter Clone Let’s make simple Twitter. Users can post tweets and see everyone’s them. To make the project simple, we do not have a sign/login function. So there are not user accounts and follow function. You can challenge after you finish the course.
Live Replit Link --> https://twitter-clone.arpanghosh7.repl.co/
# Screenshot
![Screenshot 2022-11-07 at 2 26 18 PM](https://user-images.githubusercontent.com/113170296/200268720-057d5adb-3dc2-468c-b2c3-ba17987cfbe8.png)


# Technologies Used
* HTML
* CSS
* Bootstrap
* Javascript/JQuery
* Django
* Cloudinary(To host uploaded images on CDN)
# User Story
* User can post tweets.
* Users canedit tweets.
* Users can delete tweets.
* Users can send a like to a tweet

