# Portfolio

This is my portfolio project using HTML/CSS and Bootstrap. I will be using this to show case my project!


[live Replit Deployment](https://portfolio.arpanghosh7.repl.co/)
<img width="1423" alt="Screenshot 2022-09-28 at 10 53 03 AM" src="https://user-images.githubusercontent.com/113170296/192694314-7431e586-e32d-426c-8119-8431d4e00f49.png">

## Technologies Used
*HTML
*CSS

## Istallation
No need to install any software, just open up index.html

## How to use?
Use this template to build your own portfolio

Replit link --> https://Portfolio.arpanghosh7.repl.co
